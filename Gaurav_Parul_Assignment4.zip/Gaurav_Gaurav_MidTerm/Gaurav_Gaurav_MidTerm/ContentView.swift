//
//  ContentView.swift
//  Gaurav_Gaurav_MidTerm
//
//  Created by a on 2023-07-20.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var carbonIntensity = CarbonIntensity()

    var body: some View {
        VStack {
            Text("Gaurav").font(.title)
                                       .fontWeight(.bold)
                                       .padding(.bottom, 20)
                                   
                                   Text("UK Regional Carbon Intensity")
                                       .font(.title)
                                       .fontWeight(.bold)
                                       .padding(.bottom, 20)
            Text("dnoregion: \(carbonIntensity.dnoregion)")
            Text("forecast: \(carbonIntensity.forecast)")
            Text("index: \(carbonIntensity.index)")
        }
        .onAppear {
            carbonIntensity.fetchData() // Fetch JSON data when the ContentView appears
        }
    }
}
