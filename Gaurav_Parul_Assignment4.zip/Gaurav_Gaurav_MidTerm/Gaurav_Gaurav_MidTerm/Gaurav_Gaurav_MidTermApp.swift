//
//  Gaurav_Gaurav_MidTermApp.swift
//  Gaurav_Gaurav_MidTerm
//
//  Created by aon 2023-07-20.
//

import SwiftUI

@main
struct Gaurav_Gaurav_MidTermApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
