//
//  YourJSONDataModel.swift
//  Gaurav_Gaurav_MidTerm
//
//  Created by adithyasai neeli on 2023-07-20.
//

import Foundation

struct YourJSONDataModel:
