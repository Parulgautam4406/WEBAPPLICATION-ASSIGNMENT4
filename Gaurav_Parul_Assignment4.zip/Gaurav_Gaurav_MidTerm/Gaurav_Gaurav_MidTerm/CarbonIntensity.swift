//
//  CarbonIntensity.swift
//  Gaurav_Gaurav_MidTerm
//
//  Created by a on 2023-07-20.
//

import Foundation
import Combine

class CarbonIntensity: ObservableObject {
    @Published var dnoregion: String = ""
        @Published var forecast: Int = 0
        @Published var index: String = ""

        init() {
            fetchData()
        }

        func fetchData() {
            guard let url = URL(string: "https://api.carbonintensity.org.uk/regional/postcode/M60") else {
                print("Invalid URL")
                return
            }

            URLSession.shared.dataTaskPublisher(for: url)
                .map { $0.data }
                .decode(type: ResponseData.self, decoder: JSONDecoder())
                .receive(on: DispatchQueue.main)
                .sink(receiveCompletion: { completion in
                    switch completion {
                    case .failure(let error):
                        print("Data fetch failed: \(error)")
                    case .finished:
                        break
                    }
                }, receiveValue: { [weak self] responseData in
                    // Access the fetched data here
                    if let region = responseData.data.first,
                       let dataPoint = region.data.first {
                        self?.dnoregion = region.dnoregion
                        self?.forecast = dataPoint.intensity.forecast
                        self?.index = dataPoint.intensity.index
                    }
                })
                .store(in: &cancellables)
        }

        private var cancellables = Set<AnyCancellable>()
    }

    struct ResponseData: Codable {
        let data: [Region]
    }

    struct Region: Codable {
        let regionid: Int
        let dnoregion: String
        let shortname: String
        let postcode: String
        let data: [DataPoint]
    }

    struct DataPoint: Codable {
        let from: String
        let to: String
        let intensity: Intensity
        let generationmix: [GenerationMix]
    }

    struct Intensity: Codable {
        let forecast: Int
        let index: String
    }

    struct GenerationMix: Codable {
        let fuel: String
        let perc: Double
    }
